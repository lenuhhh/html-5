# 🌿 Green Region — React App

Full React app with **real email sending** (orders + contact + chat notifications).

---

## 📁 Project Structure

```
greenregion-react/
├── src/
│   ├── config.js              ← ⭐ All your keys go here
│   ├── hooks/
│   │   ├── useEmail.js        ← EmailJS logic (orders + chat)
│   │   └── useCart.js         ← Shopping cart state
│   ├── components/
│   │   ├── Navbar.jsx
│   │   ├── ProductCard.jsx
│   │   └── ChatWidget.jsx     ← Live chat with email notification
│   ├── pages/
│   │   ├── HomePage.jsx
│   │   ├── CatalogPage.jsx
│   │   ├── OrderPage.jsx      ← 4-step wizard + email on submit
│   │   └── ContactPage.jsx    ← Contact form + email
│   └── data/products.js
└── README.md
```

---

## 🚀 Quick Start

```bash
npm install
npm run dev
# → http://localhost:5173
```

---

## 📧 Email Setup (EmailJS — FREE, no backend needed)

EmailJS sends emails directly from the browser. **200 emails/month free.**

### Step 1 — Create account
Go to [https://emailjs.com](https://emailjs.com) → Sign Up (free)

### Step 2 — Add Gmail service
1. Dashboard → **Email Services** → **Add New Service**
2. Choose **Gmail**
3. Click **Connect Account** → authorize your Gmail
4. Copy the **Service ID** (e.g. `service_abc123`)

### Step 3 — Create 3 email templates

#### Template 1: `template_order` — Order notification to manager
**To email:** your manager's Gmail  
**Subject:** `New Order #{{order_id}} from {{customer_name}}`

```
New order received!

Order: {{order_id}}
Date: {{order_date}}

CUSTOMER:
Name: {{customer_name}}
Email: {{customer_email}}
Phone: {{customer_phone}}
Company: {{company}}
Address: {{address}}

ORDER ITEMS:
{{items_list}}

TOTAL: {{total}}

Comments: {{comments}}
```

> Set **Reply-To** → `{{customer_email}}` so you can hit Reply directly

---

#### Template 2: `template_autoreply` — Auto-confirm to customer
**To email:** `{{customer_email}}`  
**Subject:** `✅ Order #{{order_id}} confirmed — Green Region`

```
Hello {{customer_name}}!

Your order has been received.

Order: #{{order_id}}
Total: {{total}}

Items:
{{items_list}}

Our manager will contact you within 30 minutes.

— Green Region Team
```

---

#### Template 3: `template_chat` — Chat/contact notification
**To email:** your manager's Gmail  
**Subject:** `💬 New message from {{visitor_name}}`

```
New message from website chat/contact form:

From: {{visitor_name}}
Email: {{visitor_email}}
Time: {{sent_at}}

Message:
{{message}}

---
Reply to: {{visitor_email}}
```

> Set **Reply-To** → `{{visitor_email}}`

---

### Step 4 — Get your Public Key
Dashboard → **Account** → **General** → **Public Key**

### Step 5 — Fill in config.js

```js
// src/config.js
export const EMAIL_CONFIG = {
  PUBLIC_KEY:            'user_xxxxxxxxxxxxxxx',   // ← paste here
  SERVICE_ID:            'service_abc123',          // ← paste here
  ORDER_TEMPLATE_ID:     'template_order',
  AUTO_REPLY_TEMPLATE_ID:'template_autoreply',
  CHAT_TEMPLATE_ID:      'template_chat',
  BUSINESS_EMAIL:        'your@gmail.com',
};
```

✅ **That's it. Emails work.**

---

## 🌐 Deploy to Vercel (FREE)

### Option A — Vercel CLI
```bash
npm install -g vercel
vercel login
vercel
# Follow prompts: Framework = Vite, build = dist
```

### Option B — GitHub
1. Push to GitHub
2. Go to [vercel.com](https://vercel.com) → **New Project** → Import repo
3. Framework: **Vite** (auto-detected)
4. Click **Deploy**

Your app is live at `https://greenregion.vercel.app` 🎉

---

## 🗄️ Vercel Postgres — Is it suitable?

### YES — Vercel Postgres works great for this project

**What it gives you:**
- PostgreSQL database hosted by Vercel
- Free tier: 256 MB storage, 60 hours compute/month
- Auto-connects to your Vercel project
- SQL via `@vercel/postgres` package

**What to store in it:**
| Table | Purpose |
|-------|---------|
| `orders` | Order history, statuses |
| `chat_messages` | Chat history per visitor |
| `visitors` | Returning visitor recognition |

### How to add Vercel Postgres

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Link project
vercel link

# 3. Create DB on Vercel Dashboard:
#    Your project → Storage → Create Database → Postgres

# 4. Pull env variables locally
vercel env pull .env.local
# This creates POSTGRES_URL, POSTGRES_PRISMA_URL, etc.

# 5. Install client
npm install @vercel/postgres
```

### Create tables (run once)
```sql
-- orders table
CREATE TABLE orders (
  id          TEXT PRIMARY KEY,
  customer    JSONB NOT NULL,
  items       JSONB NOT NULL,
  total       INTEGER NOT NULL,
  status      TEXT DEFAULT 'new',
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- chat_messages table
CREATE TABLE chat_messages (
  id          SERIAL PRIMARY KEY,
  session_id  TEXT NOT NULL,
  visitor_name TEXT,
  visitor_email TEXT,
  role        TEXT NOT NULL,  -- 'user' or 'manager'
  message     TEXT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
```

### API route example (Vercel serverless)
Create `api/order.js`:
```js
import { sql } from '@vercel/postgres';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  
  const { orderId, customer, items, total } = req.body;
  
  await sql`
    INSERT INTO orders (id, customer, items, total)
    VALUES (${orderId}, ${JSON.stringify(customer)}, ${JSON.stringify(items)}, ${total})
  `;
  
  res.json({ success: true });
}
```

---

## 💬 How Email Chat Works

```
User fills in name + email in chat widget
         ↓
User sends first message
         ↓
EmailJS → sends to manager's Gmail:
  "New message from Visitor Name
   Email: visitor@gmail.com
   Message: ..."
         ↓
Manager hits REPLY in Gmail
         ↓
Reply goes to visitor@gmail.com ✓
```

**For REAL-TIME replies** (message appears in browser without refresh):
→ Use the `greenregion-chat.zip` Socket.io server from the previous session.

---

## 🔑 Summary: What you need to fill in

| File | Variable | Where to get it |
|------|----------|-----------------|
| `src/config.js` | `PUBLIC_KEY` | emailjs.com → Account → General |
| `src/config.js` | `SERVICE_ID` | emailjs.com → Email Services |
| `src/config.js` | `ORDER_TEMPLATE_ID` | emailjs.com → Email Templates |
| `src/config.js` | `AUTO_REPLY_TEMPLATE_ID` | emailjs.com → Email Templates |
| `src/config.js` | `CHAT_TEMPLATE_ID` | emailjs.com → Email Templates |
| `src/config.js` | `BUSINESS_EMAIL` | your Gmail address |

Total setup time: **~15 minutes**.
