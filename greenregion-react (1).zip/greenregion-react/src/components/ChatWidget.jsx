import { useState, useRef, useEffect, useCallback } from 'react';
import { useEmail } from '../hooks/useEmail';
import styles from './ChatWidget.module.css';

const AUTO_RESPONSES = [
  { re: /order|buy|purchase/i,         msg: 'Great! Use our Order page (top menu) for a step-by-step wizard, or tell me here what you need! 🛒' },
  { re: /deliver|shipping|today/i,     msg: 'We deliver Mon–Sat. Same-day delivery for orders placed before 10:00 AM. 🚚' },
  { re: /price|cost|wholesale|min/i,   msg: 'Wholesale from 50 kg (vegetables) or 500 stems (flowers). I\'ll prepare a personal quote — just tell me quantities. 📋' },
  { re: /hello|hi|hey/i,               msg: 'Hello! 👋 Welcome to Green Region. Ask me anything about products, prices or delivery!' },
  { re: /organic|certif|eco/i,         msg: 'All products are pesticide-free and certified organic. Lab-tested every batch. 🌿' },
  { re: /flower|rose|tulip|orchid/i,   msg: 'Fresh Holland roses, tulips, orchids — cut daily from our greenhouses. 🌸 What quantity?' },
  { re: /tomato|cucumber|pepper/i,     msg: 'Year-round organic greenhouse vegetables — cherry tomatoes, cucumbers, peppers. 🍅 How much?' },
];

function getAutoReply(text) {
  for (const r of AUTO_RESPONSES) {
    if (r.re.test(text)) return r.msg;
  }
  return 'Thank you! 🌿 Our manager will reply to your email shortly. You can also call us at +380 (000) 000-00-00.';
}

function fmtTime() {
  return new Date().toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' });
}

const QUICK_REPLIES = [
  '📦 Minimum order?',
  '🚚 Delivery today?',
  '💰 Wholesale prices?',
  '🛒 Place an order',
];

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState('intro'); // intro | chat
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [input, setInput] = useState('');
  const [msgs, setMsgs] = useState([]);
  const [typing, setTyping] = useState(false);
  const [unread, setUnread] = useState(0);
  const [emailSent, setEmailSent] = useState(false);
  const endRef = useRef(null);
  const taRef = useRef(null);
  const { sendChatNotification } = useEmail();

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [msgs, typing]);

  const addMsg = useCallback((role, text) => {
    setMsgs(prev => [...prev, { id: Date.now() + Math.random(), role, text, time: fmtTime() }]);
  }, []);

  const startChat = useCallback(() => {
    if (!name.trim()) return;
    setStep('chat');
    addMsg('manager', `Hello ${name}! 👋 I'm your Green Region manager. How can I help you today?`);
  }, [name, addMsg]);

  const sendMessage = useCallback(async (text) => {
    if (!text.trim()) return;
    addMsg('user', text.trim());
    setInput('');
    if (taRef.current) taRef.current.style.height = 'auto';

    // Typing indicator
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      addMsg('manager', getAutoReply(text));
    }, 900 + Math.random() * 1000);

    // Send email notification to manager (first message only)
    if (!emailSent) {
      setEmailSent(true);
      try {
        await sendChatNotification({
          visitorName: name,
          visitorEmail: email,
          message: text.trim(),
        });
      } catch (e) {
        // silently fail if EmailJS not configured yet
        console.log('Email not sent (configure EmailJS):', e.message);
      }
    }
  }, [addMsg, emailSent, name, email, sendChatNotification]);

  const handleSend = () => sendMessage(input);
  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const toggle = () => {
    setOpen(o => !o);
    if (!open) setUnread(0);
  };

  return (
    <div className={styles.root}>
      {/* Window */}
      {open && (
        <div className={styles.window}>
          {/* Header */}
          <div className={styles.header}>
            <div className={styles.avatar}>
              🌿
              <div className={styles.onlineDot} />
            </div>
            <div>
              <div className={styles.hName}>Green Region Support</div>
              <div className={styles.hStatus}>● Replies in minutes</div>
            </div>
            <button className={styles.closeBtn} onClick={toggle}>✕</button>
          </div>

          {/* Intro step */}
          {step === 'intro' && (
            <div className={styles.intro}>
              <div className={styles.introTitle}>👋 Hi! Welcome to Green Region</div>
              <div className={styles.introSub}>
                Tell us your name to chat with our manager. We reply in minutes!
              </div>
              <input className={`form-input ${styles.introInput}`} placeholder="Your name *"
                value={name} onChange={e => setName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && startChat()} />
              <input className={`form-input ${styles.introInput}`} placeholder="Email (for manager's reply)"
                type="email" value={email} onChange={e => setEmail(e.target.value)} />
              <button className={`btn-primary ${styles.startBtn}`} onClick={startChat} disabled={!name.trim()}>
                Start Chat →
              </button>
            </div>
          )}

          {/* Chat step */}
          {step === 'chat' && (
            <>
              <div className={styles.msgs}>
                {msgs.map(m => (
                  <div key={m.id} className={`${styles.msg} ${styles[m.role]}`}>
                    <div className={styles.bubble}>{m.text}</div>
                    <div className={styles.time}>{m.time}</div>
                  </div>
                ))}
                {typing && (
                  <div className={styles.typingRow}>
                    <span className={styles.td} /><span className={styles.td} /><span className={styles.td} />
                  </div>
                )}
                <div ref={endRef} />
              </div>

              {/* Quick replies — show only before first user message */}
              {msgs.filter(m => m.role === 'user').length === 0 && (
                <div className={styles.qr}>
                  {QUICK_REPLIES.map(q => (
                    <button key={q} className={styles.qrBtn}
                      onClick={() => sendMessage(q.replace(/^[^\w]+/, '').trim())}>
                      {q}
                    </button>
                  ))}
                </div>
              )}

              <div className={styles.inputArea}>
                <textarea ref={taRef} className={styles.ta} rows={1}
                  placeholder="Type a message…" value={input}
                  onChange={e => {
                    setInput(e.target.value);
                    e.target.style.height = 'auto';
                    e.target.style.height = Math.min(e.target.scrollHeight, 96) + 'px';
                  }}
                  onKeyDown={handleKey} />
                <button className={styles.sendBtn} onClick={handleSend} disabled={!input.trim()}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
                  </svg>
                </button>
              </div>

              {email && (
                <div className={styles.emailNote}>
                  📧 Manager's reply will also go to <b>{email}</b>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* FAB */}
      <button className={styles.fab} onClick={toggle} title="Chat with us">
        {unread > 0 && !open && <div className={styles.badge}>{unread}</div>}
        {open
          ? <svg width="22" height="22" viewBox="0 0 24 24" fill="#b8d87a">
              <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
            </svg>
          : <svg width="22" height="22" viewBox="0 0 24 24" fill="#b8d87a">
              <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/>
            </svg>
        }
      </button>
    </div>
  );
}
