import styles from './ProductCard.module.css';

export default function ProductCard({ product, onAdd }) {
  return (
    <div className={styles.card}>
      {product.badge && (
        <span className={`${styles.badge} ${product.hot ? styles.hot : ''}`}>
          {product.badge}
        </span>
      )}
      <div className={styles.img}>{product.emoji}</div>
      <div className={styles.body}>
        <div className={styles.name}>{product.name}</div>
        <div className={styles.price}>
          {product.price} ₴
          <span className={styles.unit}>/{product.unit}</span>
        </div>
        <button className={styles.addBtn} onClick={() => onAdd(product)}>
          + Add to order
        </button>
      </div>
    </div>
  );
}
