import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import styles from './Navbar.module.css';

const NAV_LINKS = [
  { to: '/',        label: 'Home' },
  { to: '/catalog', label: 'Catalog' },
  { to: '/order',   label: 'Order' },
  { to: '/about',   label: 'About' },
  { to: '/contact', label: 'Contact' },
];

export default function Navbar({ cartCount }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  return (
    <nav className={styles.nav}>
      <div className={`${styles.inner} container`}>
        <Link to="/" className={styles.logo}>
          <div className={styles.logoLeaf}>🌿</div>
          <span>Green Region</span>
        </Link>

        <div className={styles.links}>
          {NAV_LINKS.map(l => (
            <Link key={l.to} to={l.to}
              className={`${styles.link} ${location.pathname === l.to ? styles.active : ''}`}>
              {l.label}
            </Link>
          ))}
        </div>

        <div className={styles.right}>
          <Link to="/order" className={styles.cartBtn}>
            🛒
            {cartCount > 0 && <span className={styles.cartBadge}>{cartCount}</span>}
          </Link>
          <button className={styles.burger} onClick={() => setMenuOpen(o => !o)}>
            <span /><span /><span />
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className={styles.mobileMenu}>
          {NAV_LINKS.map(l => (
            <Link key={l.to} to={l.to} className={styles.mobileLink}
              onClick={() => setMenuOpen(false)}>
              {l.label}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
}
