export const PRODUCTS = [
  { id:1,  name:'Cherry Tomato',       emoji:'🍅', category:'vegetables', price:320,  unit:'kg',    badge:'HIT',   hot:true  },
  { id:2,  name:'Dutch Cucumber',      emoji:'🥒', category:'vegetables', price:180,  unit:'kg',    badge:'FRESH', hot:false },
  { id:3,  name:'Holland Red Rose',    emoji:'🌹', category:'flowers',    price:89,   unit:'pcs',   badge:'TOP',   hot:false },
  { id:4,  name:'Sochi Strawberry',    emoji:'🍓', category:'fruits',     price:450,  unit:'kg',    badge:'NEW',   hot:true  },
  { id:5,  name:'Green Basil',         emoji:'🌿', category:'greens',     price:120,  unit:'bunch', badge:'ECO',   hot:false },
  { id:6,  name:'Tulip Mix',           emoji:'🌷', category:'flowers',    price:65,   unit:'pcs',   badge:'',      hot:false },
  { id:7,  name:'Rotunda Pepper',      emoji:'🫑', category:'vegetables', price:260,  unit:'kg',    badge:'',      hot:false },
  { id:8,  name:'Meyer Lemon',         emoji:'🍋', category:'fruits',     price:380,  unit:'kg',    badge:'EXOTIC',hot:false },
  { id:9,  name:'Banana',              emoji:'🍌', category:'fruits',     price:280,  unit:'kg',    badge:'EXOTIC',hot:false },
  { id:10, name:'Curly Parsley',       emoji:'🌾', category:'greens',     price:80,   unit:'bunch', badge:'',      hot:false },
  { id:11, name:'Phalaenopsis Orchid', emoji:'🌸', category:'flowers',    price:890,  unit:'pcs',   badge:'LUX',   hot:true  },
  { id:12, name:'Eggplant',            emoji:'🍆', category:'vegetables', price:220,  unit:'kg',    badge:'',      hot:false },
  { id:13, name:'Passion Fruit',       emoji:'🍈', category:'exotic',     price:720,  unit:'kg',    badge:'EXOTIC',hot:false },
];

export const CATEGORIES = ['all', 'vegetables', 'fruits', 'flowers', 'greens', 'exotic'];
