import { useState } from 'react';
import { PRODUCTS, CATEGORIES } from '../data/products';
import ProductCard from '../components/ProductCard';
import styles from './CatalogPage.module.css';

export default function CatalogPage({ onAdd }) {
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const filtered = PRODUCTS.filter(p =>
    (filter === 'all' || p.category === filter) &&
    (p.name.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className={styles.page}>
      <div className={styles.hero}>
        <div className="container">
          <span className="section-eyebrow">Our products</span>
          <h1 className="section-title">Product Catalog</h1>
          <p className="section-sub">Fresh organic vegetables, fruits, flowers and greens straight from our greenhouses.</p>
        </div>
      </div>
      <div className={`container ${styles.content}`}>
        <div className={styles.controls}>
          <input className={`form-input ${styles.search}`} placeholder="🔍 Search products…"
            value={search} onChange={e => setSearch(e.target.value)} />
          <div className={styles.filters}>
            {CATEGORIES.map(c => (
              <button key={c} className={`${styles.filterBtn} ${filter === c ? styles.active : ''}`}
                onClick={() => setFilter(c)}>
                {c === 'all' ? 'All' : c.charAt(0).toUpperCase() + c.slice(1)}
              </button>
            ))}
          </div>
        </div>
        <div className={styles.grid}>
          {filtered.map(p => <ProductCard key={p.id} product={p} onAdd={onAdd} />)}
          {filtered.length === 0 && <div className={styles.empty}>No products found 🌿</div>}
        </div>
      </div>
    </div>
  );
}
