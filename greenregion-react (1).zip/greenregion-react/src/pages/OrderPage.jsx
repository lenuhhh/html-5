import { useState } from 'react';
import { PRODUCTS, CATEGORIES } from '../data/products';
import { useEmail } from '../hooks/useEmail';
import toast from 'react-hot-toast';
import styles from './OrderPage.module.css';

const uid = () => 'GR-' + Date.now().toString(36).toUpperCase();

export default function OrderPage({ cart, onAdd, onChangeQty, onRemove, onClear }) {
  const [step, setStep] = useState(1); // 1=select cat, 2=pick products, 3=qty+details, 4=confirm, 5=success
  const [category, setCategory] = useState('');
  const [filter, setFilter] = useState('all');
  const [customer, setCustomer] = useState({ name:'', email:'', phone:'', company:'', address:'', comments:'' });
  const [sending, setSending] = useState(false);
  const [orderId] = useState(uid);
  const { sendOrder } = useEmail();

  const total = cart.reduce((s, i) => s + i.product.price * i.qty, 0);
  const filteredProducts = PRODUCTS.filter(p =>
    (category === '' || p.category === category) &&
    (filter === 'all' || p.category === filter)
  );

  const handleSubmit = async () => {
    if (!customer.name.trim() || !customer.email.includes('@')) {
      toast.error('Please fill in name and email');
      return;
    }
    if (cart.length === 0) { toast.error('Your cart is empty'); return; }
    setSending(true);
    try {
      await sendOrder({ items: cart, customer, total, orderId });
      toast.success('Order sent! Check your email 📧');
      onClear();
      setStep(5);
    } catch (e) {
      // EmailJS not configured → show success anyway (demo mode)
      console.warn('Email not sent (configure EmailJS):', e.message);
      toast('Order saved! Configure EmailJS to send emails.', { icon: '⚠️' });
      onClear();
      setStep(5);
    } finally {
      setSending(false);
    }
  };

  // ── STEP 5: Success ──────────────────────────────────────────────────
  if (step === 5) return (
    <div className={styles.page}>
      <div className={styles.successWrap}>
        <div className={styles.successIcon}>✅</div>
        <h1 className={styles.successTitle}>Order Submitted!</h1>
        <p className={styles.successSub}>
          Order <strong>{orderId}</strong> has been sent.<br />
          Confirmation email sent to <strong>{customer.email || 'you'}</strong>.<br />
          Our manager will contact you within 30 minutes.
        </p>
        <button className="btn-primary" onClick={() => { setStep(1); setCategory(''); }}>
          Place Another Order
        </button>
      </div>
    </div>
  );

  return (
    <div className={styles.page}>
      {/* Progress bar */}
      <div className={styles.progress}>
        {[1,2,3,4].map(n => (
          <div key={n} className={styles.progressItem}>
            <div className={`${styles.progressDot} ${step >= n ? styles.done : ''} ${step === n ? styles.current : ''}`}>{n}</div>
            <div className={styles.progressLabel}>{['Category','Products','Details','Review'][n-1]}</div>
            {n < 4 && <div className={`${styles.progressLine} ${step > n ? styles.doneLine : ''}`} />}
          </div>
        ))}
      </div>

      <div className={styles.inner}>

        {/* ── STEP 1: Category ── */}
        {step === 1 && (
          <div className="animate-fadeUp">
            <div className={styles.stepTitle}>What are you looking for?</div>
            <div className={styles.catGrid}>
              {CATEGORIES.filter(c => c !== 'all').map(cat => {
                const emoji = { vegetables:'🥦', fruits:'🍓', flowers:'🌹', greens:'🌿', exotic:'🍈' }[cat] || '📦';
                return (
                  <button key={cat} className={`${styles.catCard} ${category === cat ? styles.catSelected : ''}`}
                    onClick={() => { setCategory(cat); setFilter(cat); setStep(2); }}>
                    <span className={styles.catEmoji}>{emoji}</span>
                    <span className={styles.catName}>{cat.charAt(0).toUpperCase() + cat.slice(1)}</span>
                  </button>
                );
              })}
              <button className={`${styles.catCard} ${category === '' && step === 2 ? styles.catSelected : ''}`}
                onClick={() => { setCategory(''); setFilter('all'); setStep(2); }}>
                <span className={styles.catEmoji}>🛒</span>
                <span className={styles.catName}>All products</span>
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 2: Products ── */}
        {step === 2 && (
          <div className="animate-fadeUp">
            <div className={styles.stepTitle}>Select products</div>
            <div className={styles.filterRow}>
              {CATEGORIES.map(c => (
                <button key={c} className={`${styles.filterBtn} ${filter === c ? styles.filterActive : ''}`}
                  onClick={() => setFilter(c)}>
                  {c === 'all' ? 'All' : c.charAt(0).toUpperCase() + c.slice(1)}
                </button>
              ))}
            </div>
            <div className={styles.productGrid}>
              {filteredProducts.map(p => {
                const inCart = cart.find(i => i.product.id === p.id);
                return (
                  <div key={p.id} className={styles.pickerCard}>
                    <div className={styles.pickerEmoji}>{p.emoji}</div>
                    <div className={styles.pickerName}>{p.name}</div>
                    <div className={styles.pickerPrice}>{p.price} ₴/{p.unit}</div>
                    {inCart ? (
                      <div className={styles.qtyRow}>
                        <button className={styles.qtyBtn} onClick={() => onChangeQty(p.id, -1)}>−</button>
                        <span className={styles.qtyVal}>{inCart.qty}</span>
                        <button className={styles.qtyBtn} onClick={() => onChangeQty(p.id, 1)}>+</button>
                      </div>
                    ) : (
                      <button className={styles.addBtn} onClick={() => onAdd(p)}>+ Add</button>
                    )}
                  </div>
                );
              })}
            </div>
            <div className={styles.stepNav}>
              <button className="btn-outline" onClick={() => setStep(1)}>← Back</button>
              <button className="btn-primary" onClick={() => setStep(3)} disabled={cart.length === 0}>
                Next: Details ({cart.length} items) →
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 3: Details ── */}
        {step === 3 && (
          <div className="animate-fadeUp">
            <div className={styles.stepTitle}>Quantities & Your Details</div>
            <div className={styles.orderTable}>
              <div className={styles.orderTableHead}>
                <span>Product</span><span>Qty</span><span>Price</span>
              </div>
              {cart.map(i => (
                <div key={i.product.id} className={styles.orderRow}>
                  <div className={styles.orderProduct}>
                    <span>{i.product.emoji}</span>
                    <div>
                      <div className={styles.orderName}>{i.product.name}</div>
                      <div className={styles.orderUnit}>{i.product.price} ₴/{i.product.unit}</div>
                    </div>
                  </div>
                  <div className={styles.qtyRow}>
                    <button className={styles.qtyBtn} onClick={() => onChangeQty(i.product.id, -1)}>−</button>
                    <span className={styles.qtyVal}>{i.qty}</span>
                    <button className={styles.qtyBtn} onClick={() => onChangeQty(i.product.id, 1)}>+</button>
                  </div>
                  <div className={styles.orderLineTotal}>{(i.product.price * i.qty).toLocaleString('uk')} ₴</div>
                </div>
              ))}
              <div className={styles.orderTotal}>
                Total: <strong>{total.toLocaleString('uk')} ₴</strong>
              </div>
            </div>

            <div className={styles.formGrid}>
              <div className="form-group">
                <label>Name *</label>
                <input className="form-input" placeholder="Ivan Ivanov" value={customer.name}
                  onChange={e => setCustomer(p => ({...p, name: e.target.value}))} />
              </div>
              <div className="form-group">
                <label>Email * (for confirmation)</label>
                <input className="form-input" type="email" placeholder="ivan@example.com" value={customer.email}
                  onChange={e => setCustomer(p => ({...p, email: e.target.value}))} />
              </div>
              <div className="form-group">
                <label>Phone</label>
                <input className="form-input" placeholder="+380 (___) ___-__-__" value={customer.phone}
                  onChange={e => setCustomer(p => ({...p, phone: e.target.value}))} />
              </div>
              <div className="form-group">
                <label>Company</label>
                <input className="form-input" placeholder="Your company" value={customer.company}
                  onChange={e => setCustomer(p => ({...p, company: e.target.value}))} />
              </div>
              <div className="form-group" style={{ gridColumn: '1/-1' }}>
                <label>Delivery Address</label>
                <input className="form-input" placeholder="City, Street, Building" value={customer.address}
                  onChange={e => setCustomer(p => ({...p, address: e.target.value}))} />
              </div>
              <div className="form-group" style={{ gridColumn: '1/-1' }}>
                <label>Comments</label>
                <textarea className="form-input" placeholder="Any special requests…" rows={3} value={customer.comments}
                  onChange={e => setCustomer(p => ({...p, comments: e.target.value}))} />
              </div>
            </div>

            <div className={styles.stepNav}>
              <button className="btn-outline" onClick={() => setStep(2)}>← Back</button>
              <button className="btn-primary" onClick={() => {
                if (!customer.name.trim() || !customer.email.includes('@')) {
                  toast.error('Name and valid email required'); return;
                }
                setStep(4);
              }}>
                Review Order →
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 4: Review & Submit ── */}
        {step === 4 && (
          <div className="animate-fadeUp">
            <div className={styles.stepTitle}>Review & Submit</div>
            <div className={styles.reviewCard}>
              <div className={styles.reviewSection}>
                <div className={styles.reviewLabel}>📦 Order #{orderId}</div>
                {cart.map(i => (
                  <div key={i.product.id} className={styles.reviewItem}>
                    <span>{i.product.emoji} {i.product.name} × {i.qty} {i.product.unit}</span>
                    <span>{(i.product.price * i.qty).toLocaleString('uk')} ₴</span>
                  </div>
                ))}
                <div className={styles.reviewTotal}>Total: {total.toLocaleString('uk')} ₴</div>
              </div>
              <div className={styles.reviewSection}>
                <div className={styles.reviewLabel}>👤 Customer</div>
                <div className={styles.reviewField}><b>Name:</b> {customer.name}</div>
                <div className={styles.reviewField}><b>Email:</b> {customer.email}</div>
                {customer.phone && <div className={styles.reviewField}><b>Phone:</b> {customer.phone}</div>}
                {customer.address && <div className={styles.reviewField}><b>Address:</b> {customer.address}</div>}
              </div>
              <div className={styles.emailNotice}>
                📧 Confirmation will be sent to <strong>{customer.email}</strong>
              </div>
            </div>

            <div className={styles.stepNav}>
              <button className="btn-outline" onClick={() => setStep(3)}>← Edit</button>
              <button className="btn-primary" onClick={handleSubmit} disabled={sending}>
                {sending ? '⏳ Sending…' : '✅ Submit Order'}
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
