import { Link } from 'react-router-dom';
import { PRODUCTS } from '../data/products';
import ProductCard from '../components/ProductCard';
import styles from './HomePage.module.css';

export default function HomePage({ onAdd }) {
  const hotProducts = PRODUCTS.filter(p => p.hot).slice(0, 4);

  return (
    <div className={styles.page}>
      {/* Hero */}
      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <span className="section-eyebrow">Fresh from our greenhouses</span>
            <h1 className={styles.heroTitle}>
              Greenhouse<br />
              <em>business</em><br />
              new level
            </h1>
            <p className={styles.heroSub}>
              Round-the-clock deliveries of organic vegetables, fruits and flowers.
              Wholesale and retail. Straight from our greenhouses to your door.
            </p>
            <div className={styles.heroBtns}>
              <Link to="/catalog" className="btn-primary">🛒 View Catalog</Link>
              <Link to="/order" className="btn-outline">Place Order</Link>
            </div>
          </div>
          <div className={styles.heroVisual}>
            <div className={styles.heroBlob}>🌿</div>
          </div>
        </div>
      </section>

      {/* Hot products */}
      <section className={styles.section}>
        <div className="container">
          <span className="section-eyebrow">Popular this week</span>
          <h2 className="section-title">Hot Products</h2>
          <div className={styles.grid}>
            {hotProducts.map(p => (
              <ProductCard key={p.id} product={p} onAdd={onAdd} />
            ))}
          </div>
          <div style={{ textAlign: 'center', marginTop: 32 }}>
            <Link to="/catalog" className="btn-outline">See All Products →</Link>
          </div>
        </div>
      </section>

      {/* Why us */}
      <section className={styles.whySection}>
        <div className="container">
          <h2 className="section-title">Why Green Region?</h2>
          <div className={styles.whyGrid}>
            {[
              { icon: '🌱', title: 'Certified Organic', desc: 'Pesticide-free products, lab-tested every batch.' },
              { icon: '🚚', title: 'Same-Day Delivery', desc: 'Order before 10 AM — get it today, Mon–Sat.' },
              { icon: '🏭', title: 'Own Greenhouses', desc: 'We grow it ourselves — no middlemen, fair prices.' },
              { icon: '📦', title: 'Wholesale & Retail', desc: 'From 1 kg to full pallet loads. Always fresh.' },
            ].map(w => (
              <div key={w.title} className={styles.whyCard}>
                <div className={styles.whyIcon}>{w.icon}</div>
                <h3 className={styles.whyTitle}>{w.title}</h3>
                <p className={styles.whyDesc}>{w.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className={styles.cta}>
        <div className="container">
          <h2 className={styles.ctaTitle}>Ready to order?</h2>
          <p className={styles.ctaSub}>Place your order online and get a confirmation email instantly.</p>
          <Link to="/order" className="btn-primary">Place Order Now →</Link>
        </div>
      </section>
    </div>
  );
}
