import { useState } from 'react';
import { useEmail } from '../hooks/useEmail';
import toast from 'react-hot-toast';
import styles from './ContactPage.module.css';

export default function ContactPage() {
  const [form, setForm] = useState({ name:'', email:'', phone:'', company:'', subject:'', message:'' });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const { sendChatNotification } = useEmail();

  const set = (k, v) => setForm(p => ({...p, [k]: v}));

  const handleSubmit = async () => {
    if (!form.name.trim() || !form.email.includes('@') || !form.message.trim()) {
      toast.error('Please fill in name, email and message'); return;
    }
    setSending(true);
    try {
      await sendChatNotification({
        visitorName: `${form.name} (${form.company || 'no company'})`,
        visitorEmail: form.email,
        message: `Subject: ${form.subject || 'Contact inquiry'}\nPhone: ${form.phone || '—'}\n\n${form.message}`,
      });
      toast.success('Message sent! We\'ll reply to your email 📧');
      setSent(true);
    } catch(e) {
      console.warn('Email not sent:', e.message);
      toast('Message received! Configure EmailJS to actually send emails.', { icon: '⚠️' });
      setSent(true);
    } finally {
      setSending(false);
    }
  };

  if (sent) return (
    <div className={styles.page}>
      <div className={styles.successWrap}>
        <div style={{ fontSize: 70 }}>✅</div>
        <h2 className={styles.successTitle}>Message sent!</h2>
        <p>We'll reply to <strong>{form.email}</strong> within a few hours.</p>
        <button className="btn-primary" onClick={() => { setSent(false); setForm({ name:'',email:'',phone:'',company:'',subject:'',message:'' }); }}>
          Send Another
        </button>
      </div>
    </div>
  );

  return (
    <div className={styles.page}>
      <div className={styles.hero}>
        <div className="container">
          <span className="section-eyebrow">Get in touch</span>
          <h1 className="section-title">Contact Us</h1>
          <p className="section-sub">Have a question or want to discuss a wholesale order? We'll reply within a few hours.</p>
        </div>
      </div>
      <div className={`container ${styles.content}`}>
        <div className={styles.grid}>
          <div className={styles.formBox}>
            <div className={styles.formGrid}>
              <div className="form-group">
                <label>Name *</label>
                <input className="form-input" placeholder="Ivan Ivanov" value={form.name} onChange={e => set('name', e.target.value)} />
              </div>
              <div className="form-group">
                <label>Email * (we reply here)</label>
                <input className="form-input" type="email" placeholder="ivan@example.com" value={form.email} onChange={e => set('email', e.target.value)} />
              </div>
              <div className="form-group">
                <label>Phone</label>
                <input className="form-input" placeholder="+380..." value={form.phone} onChange={e => set('phone', e.target.value)} />
              </div>
              <div className="form-group">
                <label>Company</label>
                <input className="form-input" placeholder="Your company" value={form.company} onChange={e => set('company', e.target.value)} />
              </div>
              <div className="form-group" style={{ gridColumn: '1/-1' }}>
                <label>Subject</label>
                <input className="form-input" placeholder="Wholesale inquiry…" value={form.subject} onChange={e => set('subject', e.target.value)} />
              </div>
              <div className="form-group" style={{ gridColumn: '1/-1' }}>
                <label>Message *</label>
                <textarea className="form-input" rows={5} placeholder="Tell us how we can help…" value={form.message} onChange={e => set('message', e.target.value)} />
              </div>
            </div>
            <button className="btn-primary" style={{ marginTop: 8, width: '100%', justifyContent: 'center' }}
              onClick={handleSubmit} disabled={sending}>
              {sending ? '⏳ Sending…' : '📧 Send Message'}
            </button>
          </div>
          <div className={styles.info}>
            <h3 className={styles.infoTitle}>Green Region</h3>
            <p className={styles.infoDesc}>Certified organic greenhouse produce. Wholesale & retail. Kyiv region, Ukraine.</p>
            {[
              { icon: '📞', label: 'Phone', val: '+380 (000) 000-00-00' },
              { icon: '📧', label: 'Email', val: 'info@greenregion.ua' },
              { icon: '🕐', label: 'Hours', val: 'Mon–Sat: 7:00–19:00' },
              { icon: '📍', label: 'Location', val: 'Kyiv region, Ukraine' },
            ].map(c => (
              <div key={c.label} className={styles.contact}>
                <span className={styles.contactIcon}>{c.icon}</span>
                <div>
                  <div className={styles.contactLabel}>{c.label}</div>
                  <div className={styles.contactVal}>{c.val}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
