// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  GREEN REGION — Email Configuration (EmailJS)
//  
//  Setup steps:
//  1. Register at https://emailjs.com (free — 200 emails/month)
//  2. Add Gmail service: Dashboard → Email Services → Add Service
//  3. Create two templates (see comments below)
//  4. Copy your IDs here
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const EMAIL_CONFIG = {
  // From EmailJS Dashboard → Account → Public Key
  PUBLIC_KEY: 'YOUR_PUBLIC_KEY',

  // From Dashboard → Email Services → your Gmail service ID  
  SERVICE_ID: 'YOUR_SERVICE_ID',

  // ── Template 1: Order notification ────────────────────
  // Create template with these variables:
  //   {{order_id}}  {{customer_name}}  {{customer_email}}
  //   {{customer_phone}}  {{company}}  {{address}}
  //   {{items_list}}  {{total}}  {{comments}}  {{order_date}}
  // "To email": your manager's Gmail
  // "Reply to": {{customer_email}}
  ORDER_TEMPLATE_ID: 'template_order',

  // ── Template 2: Chat message notification ─────────────
  // Create template with these variables:
  //   {{visitor_name}}  {{visitor_email}}  {{message}}
  //   {{sent_at}}  {{reply_link}}
  // "To email": your manager's Gmail
  CHAT_TEMPLATE_ID: 'template_chat',

  // ── Template 3: Auto-reply to customer ────────────────
  // Create template with these variables:
  //   {{customer_name}}  {{order_id}}  {{total}}  {{items_list}}
  // "To email": {{customer_email}}
  // "From name": Green Region
  AUTO_REPLY_TEMPLATE_ID: 'template_autoreply',

  // Your business email (shows in email footer)
  BUSINESS_EMAIL: 'YOUR_EMAIL@gmail.com',
  BUSINESS_NAME:  'Green Region',
};

// ── Vercel Postgres (chat history) ────────────────────
// If you use Vercel + Postgres:
//   1. vercel.com → your project → Storage → Create Database → Postgres
//   2. It auto-injects POSTGRES_URL into environment
//   3. Run: npx vercel env pull .env.local
// Then use in API routes: import { sql } from '@vercel/postgres'
export const DB_CONFIG = {
  // Set to true after creating Vercel Postgres DB
  ENABLED: false,
  // Auto-injected by Vercel — no need to fill manually
  // POSTGRES_URL is read from process.env in API routes
};
