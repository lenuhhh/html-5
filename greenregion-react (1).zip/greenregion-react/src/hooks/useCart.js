import { useState, useCallback } from 'react';

export function useCart() {
  const [items, setItems] = useState([]);

  const addItem = useCallback((product) => {
    setItems(prev => {
      const exists = prev.find(i => i.product.id === product.id);
      if (exists) return prev.map(i =>
        i.product.id === product.id ? { ...i, qty: i.qty + 1 } : i
      );
      return [...prev, { product, qty: 1 }];
    });
  }, []);

  const removeItem = useCallback((productId) => {
    setItems(prev => prev.filter(i => i.product.id !== productId));
  }, []);

  const changeQty = useCallback((productId, delta) => {
    setItems(prev => prev
      .map(i => i.product.id === productId ? { ...i, qty: Math.max(1, i.qty + delta) } : i)
    );
  }, []);

  const clearCart = useCallback(() => setItems([]), []);

  const total = items.reduce((s, i) => s + i.product.price * i.qty, 0);
  const count = items.reduce((s, i) => s + i.qty, 0);

  return { items, addItem, removeItem, changeQty, clearCart, total, count };
}
