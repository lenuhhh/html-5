import { useCallback } from 'react';
import emailjs from '@emailjs/browser';
import { EMAIL_CONFIG } from '../config';
import toast from 'react-hot-toast';

// Initialize EmailJS once
emailjs.init(EMAIL_CONFIG.PUBLIC_KEY);

export function useEmail() {

  // ── Send order to manager + auto-reply to customer ──────
  const sendOrder = useCallback(async (orderData) => {
    const { items, customer, total, orderId } = orderData;

    const itemsList = items
      .map(i => `${i.product.emoji} ${i.product.name}: ${i.qty} ${i.product.unit} × ${i.product.price} ₴ = ${i.product.price * i.qty} ₴`)
      .join('\n');

    const templateParams = {
      order_id:        orderId,
      customer_name:   customer.name,
      customer_email:  customer.email,
      customer_phone:  customer.phone || '—',
      company:         customer.company || '—',
      address:         customer.address || '—',
      items_list:      itemsList,
      total:           `${total.toLocaleString('uk')} ₴`,
      comments:        customer.comments || '—',
      order_date:      new Date().toLocaleString('uk-UA'),
    };

    const promises = [
      // 1. Notify manager
      emailjs.send(
        EMAIL_CONFIG.SERVICE_ID,
        EMAIL_CONFIG.ORDER_TEMPLATE_ID,
        templateParams
      ),
    ];

    // 2. Auto-reply to customer (if they gave email)
    if (customer.email) {
      promises.push(
        emailjs.send(
          EMAIL_CONFIG.SERVICE_ID,
          EMAIL_CONFIG.AUTO_REPLY_TEMPLATE_ID,
          {
            customer_name: customer.name,
            customer_email: customer.email,
            order_id:      orderId,
            total:         `${total.toLocaleString('uk')} ₴`,
            items_list:    itemsList,
          }
        )
      );
    }

    await Promise.all(promises);
    return true;
  }, []);

  // ── Send chat message notification to manager ───────────
  const sendChatNotification = useCallback(async ({ visitorName, visitorEmail, message }) => {
    await emailjs.send(
      EMAIL_CONFIG.SERVICE_ID,
      EMAIL_CONFIG.CHAT_TEMPLATE_ID,
      {
        visitor_name:  visitorName || 'Visitor',
        visitor_email: visitorEmail || '—',
        message,
        sent_at:       new Date().toLocaleString('uk-UA'),
      }
    );
  }, []);

  return { sendOrder, sendChatNotification };
}
