import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useCart } from './hooks/useCart';
import Navbar from './components/Navbar';
import ChatWidget from './components/ChatWidget';
import HomePage from './pages/HomePage';
import CatalogPage from './pages/CatalogPage';
import OrderPage from './pages/OrderPage';
import ContactPage from './pages/ContactPage';
import './index.css';

export default function App() {
  const { items, addItem, removeItem, changeQty, clearCart, total, count } = useCart();

  return (
    <BrowserRouter>
      <Navbar cartCount={count} />
      <Routes>
        <Route path="/"        element={<HomePage  onAdd={addItem} />} />
        <Route path="/catalog" element={<CatalogPage onAdd={addItem} />} />
        <Route path="/order"   element={
          <OrderPage
            cart={items} onAdd={addItem}
            onChangeQty={changeQty} onRemove={removeItem}
            onClear={clearCart} total={total}
          />
        } />
        <Route path="/contact" element={<ContactPage />} />
      </Routes>
      <ChatWidget />
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: { fontFamily: 'Jost, sans-serif', fontSize: 14, borderRadius: 12 },
          success: { iconTheme: { primary: '#1e3d1f', secondary: '#b8d87a' } },
        }}
      />
    </BrowserRouter>
  );
}
