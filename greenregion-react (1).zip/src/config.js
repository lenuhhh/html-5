// ╔══════════════════════════════════════════════════════════════════╗
// ║           GREEN REGION — CONFIGURATION FILE                     ║
// ║                                                                  ║
// ║  ⚠️  SETUP REQUIRED — Read every section marked [CHANGE THIS]   ║
// ║                                                                  ║
// ║  This file contains 6 values that MUST be replaced before       ║
// ║  the app will send any emails or work in production.            ║
// ╚══════════════════════════════════════════════════════════════════╝


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  SECTION 1 — OWNER SIGNATURE                     [CHANGE THIS]
//
//  Replace with any secret string ONLY YOU know.
//  Example: 'mysite_2026_xK9#mQ'
//
//  ⚠️  While this equals 'REPLACE_WITH_YOUR_SECRET_KEY',
//      the app runs in DEMO MODE — no real emails are sent.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export const OWNER_SIGNATURE = 'REPLACE_WITH_YOUR_SECRET_KEY';


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  SECTION 2 — EMAILJS KEYS                        [CHANGE THIS]
//
//  1. Register free at https://emailjs.com
//  2. Add Gmail service → copy SERVICE_ID
//  3. Account → General → copy Public Key
//  4. Create 3 templates (see README for template bodies)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export const EMAIL_CONFIG = {

  PUBLIC_KEY:             'REPLACE_WITH_EMAILJS_PUBLIC_KEY',  // [CHANGE THIS]
  SERVICE_ID:             'REPLACE_WITH_EMAILJS_SERVICE_ID',  // [CHANGE THIS]

  ORDER_TEMPLATE_ID:      'template_order',      // notify manager of new order
  AUTO_REPLY_TEMPLATE_ID: 'template_autoreply',  // confirm order to customer
  CHAT_TEMPLATE_ID:       'template_chat',       // notify manager of chat msg

};


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  SECTION 3 — BUSINESS INFO                       [CHANGE THIS]
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export const BUSINESS_CONFIG = {

  NAME:    'Green Region',
  EMAIL:   'REPLACE_WITH_YOUR_EMAIL@gmail.com',  // [CHANGE THIS]
  PHONE:   '+380 (000) 000-00-00',               // [CHANGE THIS]
  ADDRESS: 'Kyiv region, Ukraine',               // [CHANGE THIS]
  HOURS:   'Mon–Sat: 7:00–19:00',                // [CHANGE THIS]
  SITE:    'https://greenregion.ua',             // [CHANGE THIS]

};


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  SECTION 4 — TELEGRAM BOT (OPTIONAL)
//
//  Leave '' to skip. To enable:
//    1. @BotFather → /newbot → copy token
//    2. api.telegram.org/bot<TOKEN>/getUpdates → find chat id
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export const TELEGRAM_CONFIG = {
  BOT_TOKEN: '',   // [OPTIONAL] '7123456789:AAF-xxx...'
  CHAT_ID:   '',   // [OPTIONAL] '123456789'
};


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  SECTION 5 — VERCEL POSTGRES (OPTIONAL)
//  vercel.com → your project → Storage → Create → Postgres
//  Then: npx vercel env pull .env.local  and set ENABLED: true
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export const DB_CONFIG = {
  ENABLED: false,
};


// ── INTERNAL: demo-mode detection — do not modify ────────────
const _PLACEHOLDERS = [
  'REPLACE_WITH_YOUR_SECRET_KEY',
  'REPLACE_WITH_EMAILJS_PUBLIC_KEY',
  'REPLACE_WITH_EMAILJS_SERVICE_ID',
];
export const IS_DEMO_MODE =
  _PLACEHOLDERS.includes(OWNER_SIGNATURE) ||
  _PLACEHOLDERS.includes(EMAIL_CONFIG.PUBLIC_KEY);

if (IS_DEMO_MODE && typeof window !== 'undefined') {
  console.warn(
    '%c⚠️ GREEN REGION — DEMO MODE\n',
    'color:#c06b3a;font-size:13px;font-weight:bold',
    'config.js not configured. Emails will NOT be sent.\n',
    'Replace placeholder values in src/config.js to activate.'
  );
}
